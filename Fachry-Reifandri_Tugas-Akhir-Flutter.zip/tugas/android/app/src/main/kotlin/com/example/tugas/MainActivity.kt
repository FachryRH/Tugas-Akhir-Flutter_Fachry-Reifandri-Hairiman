package com.example.tugas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
